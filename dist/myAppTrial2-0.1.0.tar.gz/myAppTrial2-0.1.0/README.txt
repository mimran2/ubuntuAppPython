this is just a readme file to let you know that this is my 823748275th try at 
packaging software for the ubuntu software center :)
